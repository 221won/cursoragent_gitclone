def main():
    print("Hello, World!")

if __name__ == "__main__":
    main()
                
            # The code demonstrates fundamental Python concepts including:
            #    - Basic arithmetic operations (+, *)
            #    - Conditional logic (if, elif, else)
            #    - String formatting
            #    - Print statements
            #    - Comments for code documentation
# Simple code to add two numbers

# Define two numbers
num1 = 5
num2 = 7

# Add the numbers
sum = num1 + num2

# Print the result
print("The sum is:", sum)